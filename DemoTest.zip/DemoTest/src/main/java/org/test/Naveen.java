package org.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

public class Naveen  extends LoadableComponent<Naveen>{

	WebDriver driver=new ChromeDriver();
	private LoadableComponent<?>parent;
	
	public Naveen(WebDriver driver) {
		PageFactory.initElements(driver, this);	}
	
	
	public void launchChromeDriver() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Webdev\\Driver.chromedriver.exe");
		Thread.sleep(1222);
		
	}
	
	public void enterBrowserURL() {
		
		driver.get("https://www.facebook.com/");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		
	}

}
