package org.test;

//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.AfterClass;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = {"Feature"},
glue= {"org.bdd.demo.stepDefinitions.Loan"},
plugin= {"pretty",
		"json:target/cucumber.json"},
tags = "@test")


public class TestRunner extends AbstractTestNGCucumberTests
{

}
