package org.test;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.TakesScreenshot;

public class Login extends LoadableComponent<Login> {

	WebDriver driver=new ChromeDriver();
	private LoadableComponent<?>parent;
	
	public Login(WebDriver driver) {
		PageFactory.initElements(driver, this);	}

	
	@FindBy(xpath = "//*[@id='op3-element-dg1CIQWO']//img")
	public WebElement imgNewWindow;
	
	private String links="(//*[@id='sitemap']//td[1])[Size]";
	
	
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		
	}
	
	
	
	public void launchBrowserAndvalidatefirstLink(String size) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Webdev\\Driver.chromedriver.exe");
		//Mazimize current window
		driver.manage().window().maximize();
		driver.get("https://www.getcalley.com/page-sitemap.xml");
		Thread.sleep(1222);
		driver.manage().window().setSize(new Dimension(1920,1080));
		//click on first option and print screenshot
		WebElement xmlLink=driver.findElement(By.xpath(links.replaceAll("Size", size)));
		xmlLink.click();
		Thread.sleep(1000);
		if(driver.findElement(By.xpath("//*[contains(@id,'op3-element')]//img")).isDisplayed()) {
			System.out.println("new window opened successfully");
			//Call take screenshot function
			//this.takeSnapShot(driver, "c://test.png") ;
		}else  {
			System.out.println("new window not opened");
		}
			
		
	}
	
	public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{
		//Convert web driver object to TakeScreenshot
		TakesScreenshot scrShot =((TakesScreenshot)webdriver);
		//Call getScreenshotAs method to create image file
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		//Move image file to new destination
		File DestFile=new File(fileWithPath);
		//Copy file at destination
		FileUtils.copyFile(SrcFile, DestFile);
		}

	@BeforeClass
	public static void beforeClass() {
		
	}
	@AfterClass
	public void afterClass() {
		driver.quit();
	}
	
}
