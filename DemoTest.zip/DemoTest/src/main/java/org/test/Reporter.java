package org.test;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import io.cucumber.java.Scenario;

public class Reporter {

	
	public static String strLogFolderpath;
	private static int iRandTraceCntr = 0;
	public static Map<Long, String>  moduleRefMap=new LinkedHashMap<Long, String>();
	public static String featureName= null;
	public static ThreadLocal<Scenario> scenario = new ThreadLocal<Scenario>();
	
	
	static Properties objProperties;
	
	
	
	
	private static Map<Long,Map<String, Boolean>> checkTestStatusMap =  new LinkedHashMap<Long,Map<String, Boolean>>();
	static{
		Map<String,Boolean> tesmpStatus=new LinkedHashMap<String,Boolean>();
		tesmpStatus.put("Status", true);
		tesmpStatus.put("hashMinStepsReports", false);
		checkTestStatusMap.put(Thread.currentThread().getId(), tesmpStatus);
		
		
	}
	
	public static boolean isCheckTestStatus() {
		return checkTestStatusMap.get(Thread.currentThread().getId()).get("Status");
		
		
	}
	
	public static void setCheckTestStatus(boolean checkStatus) {
		
	}
	
	
	
	/**
	 * 
	 */
	
}
