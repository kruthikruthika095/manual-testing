package org.bdd.demo.stepDefinitions.Loan;

import org.openqa.selenium.WebDriver;
import org.test.Login;

import io.cucumber.java.en.Given;

public class LoginStepDefinition {

	public WebDriver driver;
	Login login;
	
	public LoginStepDefinition() {
       login =new Login(driver);
	}
	
	@Given("launch browser and validate xml links")
	public void launch_browser_and_validate_xml_links() throws Exception {
		login.launchBrowserAndvalidatefirstLink("1");
		login.launchBrowserAndvalidatefirstLink("2");
		login.launchBrowserAndvalidatefirstLink("3");
		login.launchBrowserAndvalidatefirstLink("4");
		login.launchBrowserAndvalidatefirstLink("5");
	}
	
}


