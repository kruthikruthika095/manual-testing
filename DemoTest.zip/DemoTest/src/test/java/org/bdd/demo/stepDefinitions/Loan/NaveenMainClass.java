package org.bdd.demo.stepDefinitions.Loan;

import org.openqa.selenium.WebDriver;

import org.test.Naveen;

public class NaveenMainClass {

	
	public WebDriver driver;
	Naveen naveen;
	
	public NaveenMainClass() {
		naveen =new Naveen(driver);
	}
	
	
	
	
	
	
}
